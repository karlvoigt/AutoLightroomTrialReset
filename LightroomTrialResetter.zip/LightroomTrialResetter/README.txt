
INSTALLATION INSTRUCTIONS:

Run the Installer
Check the terminal output to ensure that there are no errors
And thats it, now your Lightroom trial should automatically reset every sunday at 7 in the morning