#!/bin/bash

sudo chmod 666 /Library/Application\ Support/Adobe/Lightroom\ CC\ AMT/AMT/application.xml

sudo osascript <<END
on run
tell application "System Events"
tell XML file ("/Library/Application Support/Adobe/Lightroom CC AMT/AMT/application.xml")
tell XML element "Configuration"
tell XML element "Other"
(* set theDataElements to every XML element whose name = "TrialSerialNumber" *)
set trialElement to (the first XML element whose XML attribute "key"'s value is "TrialSerialNumber")
set trialnumstr to (value of trialElement) as string
end tell
end tell
end tell
end tell

set tempnum to (characters -5 thru -1 of trialnumstr) as string as number
set trialnum to ((characters 1 thru -6 of trialnumstr) as string) & (tempnum + 1) as string

set stringToFind to trialnumstr
set stringToReplace to trialnum
set theFile to POSIX file ("/Library/Application Support/Adobe/Lightroom CC AMT/AMT/application.xml")
set theContent to read theFile as «class utf8»
set {oldTID, AppleScript's text item delimiters} to {AppleScript's text item delimiters, stringToFind}
set ti to every text item of theContent
set AppleScript's text item delimiters to stringToReplace
set newContent to ti as string
set AppleScript's text item delimiters to oldTID
try
set fd to open for access file theFile with write permission
set eof of fd to 0
write newContent to fd as «class utf8»
close access fd
on error
close access file theFile
end try
end run
END



sudo chmod 644 /Library/Application\ Support/Adobe/Lightroom\ CC\ AMT/AMT/application.xml

